<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
<?php
  include('css/menu.css');
?>
</style>
</head>
<body>

<ul class="topnav">
  <li><a href="stocks.php">Stocks</a></li>
  <li><a href="rice.php">Rice</a></li>
  <li><a href="records.php">Records</a></li>
  <li><a href="billing.php">Billing</a></li>
  <li><a href="customer.php">customer</a></li>
  <li><a href="dmenu.php">Display</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
